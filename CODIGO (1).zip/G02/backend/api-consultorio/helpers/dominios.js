const dominios = {
    ID_ROL_PACIENTES: "63873e6f8ee36054a39b1d2a",
    ESTADO_ACTIVO_USUARIO: 1,
    ESTADO_INACTIVO_USUARIO: 2,
    ESTADO_ACTIVO_ROL: 1,
    ESTADO_INACTIVO_ROL: 2
}
export default dominios;