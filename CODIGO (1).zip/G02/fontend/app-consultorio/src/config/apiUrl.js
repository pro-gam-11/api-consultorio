const urlBackend = {
    apiUrl: 'http://localhost:4000'
}
export default urlBackend;