import React, { useState, useEffect } from 'react';
import BreadCrumd from '../../componentes/BreadCrumb';
import Header from '../../componentes/Header';
import Sidebar from '../../componentes/Sidebar';
import APIInvoke from '../../helpers/APIInvoke.js';
import { Link } from "react-router-dom";
import mensajesFlotantes from '../../helpers/mensajesFlotantes.js';
import dominios from '../../helpers/dominios';

const UsuariosAdmin = () => {

    const [arreglo, setArreglo] = useState([]);

    const listar = async () => {
        const response = await APIInvoke.invokeGET(`/api/usuarios`);
        setArreglo(response);
    }

    useEffect(() => {
        listar();
    }, []);

    const borrar = async (e, id) => {
        e.preventDefault();
        const response = await APIInvoke.invokeDELETE(`/api/especialidades/${id}`);

        if (response.ok === "SI") {
            mensajesFlotantes('success', response.msg);
            listar();
        } else {
            mensajesFlotantes('error', response.msg);
        }
    }

    return (
        <>
            <Header></Header>
            <Sidebar></Sidebar>
            <main id="main" className="main">
                <BreadCrumd
                    BreadCrumd1={"Configuración"}
                    BreadCrumd2={"Listado Usuarios"}
                    BreadCrumd3={""}
                    ruta={"/usuarios-admin"}
                />

                <section className="section dashboard">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">

                                <div className="card">
                                    <div className="card-body">
                                        <h5 className="card-title">Usuarios</h5>

                                        <div className="col-lg-12 mb-3">
                                            <Link to={"/usuarios-crear"} className="btn btn-primary">Crear</Link>
                                        </div>

                                        {
                                            arreglo.length === 0 ?

                                                <div className="alert alert-warning alert-dismissible fade show" role="alert">
                                                    No existen ciudades.
                                                    <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close" />
                                                </div>

                                                :

                                                <div className="table-responsive">
                                                    <table className="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th style={{ width: '15%', textAlign: "center" }}>Rol</th>
                                                                <th style={{ width: '15%', textAlign: "center" }}>Ciudad</th>
                                                                <th style={{ width: '25%', textAlign: "center" }}>Nombre</th>
                                                                <th style={{ width: '10%', textAlign: "center" }}>Celular</th>
                                                                <th style={{ width: '15%', textAlign: "center" }}>Usuario</th>
                                                                <th style={{ width: '10%', textAlign: "center" }}>Estado</th>
                                                                <th style={{ width: '10%', textAlign: "center" }}>Opciones</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {
                                                                arreglo.map(
                                                                    elemento =>
                                                                        <tr key={elemento._id}>
                                                                            <td className="text-center">{elemento.idRol === null ? 'Pendiente' : elemento.idRol.nombreRol}</td>
                                                                            <td className="text-center">{elemento.idCiudad === undefined ? 'Pendiente' : elemento.idCiudad.nombreCiudad}</td>
                                                                            <td>{elemento.nombresUsuario} {elemento.apellidosUsuario}</td>
                                                                            <td className="text-center">{elemento.celularUsuario}</td>
                                                                            <td>{elemento.usuarioAcceso}</td>
                                                                            <td className="text-center">
                                                                                {
                                                                                    elemento.estadoUsuario === dominios.ESTADO_ACTIVO_USUARIO ?
                                                                                        <span className="text-success">ACTIVO</span> :
                                                                                        <span className="text-danger">INACTIVO</span>
                                                                                }
                                                                            </td>
                                                                            <td className="text-center">
                                                                                <Link to={`/especialidades-editar/${elemento._id}`} className="btn btn-primary btn-sm" title='Editar'>
                                                                                    <i className="bi bi-pencil-square" />
                                                                                </Link>
                                                                                &nbsp;
                                                                                <button onClick={(e) => borrar(e, elemento._id)} type="button" className="btn btn-danger btn-sm" title='Borrar'>
                                                                                    <i className="bi bi-trash-fill" />
                                                                                </button>
                                                                            </td>
                                                                        </tr>
                                                                )
                                                            }
                                                        </tbody>
                                                    </table>
                                                </div>
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </>
    );
}

export default UsuariosAdmin;