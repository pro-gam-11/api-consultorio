import React, { useState, useEffect } from 'react';
import BreadCrumd from '../../componentes/BreadCrumb';
import Header from '../../componentes/Header';
import Sidebar from '../../componentes/Sidebar';
import APIInvoke from '../../helpers/APIInvoke.js';
import mensajesFlotantes from '../../helpers/mensajesFlotantes.js';
import { useNavigate } from "react-router-dom";
import Form from 'react-bootstrap/Form';

const UsuariosCrear = () => {
    const navigate = useNavigate();

    const [rol, setRol] = useState('-8');
    const [arregloRoles, setArregoRoles] = useState([]);
    const [ciudad, setCiudad] = useState('-8');
    const [arregloCiudades, setArregoCiudades] = useState([]);
    const [nombres, setNombres] = useState('');
    const [apellidos, setApellidos] = useState('');
    const [correo, setCorreo] = useState('');
    const [celular, setCelular] = useState('');
    const [direccion, setDireccion] = useState('');

    const comboRoles = async () => {
        const response = await APIInvoke.invokeGET(`/api/roles/combo-roles`);
        setArregoRoles(response);
    }

    const comboCiudades = async () => {
        const response = await APIInvoke.invokeGET(`/api/ciudades`);
        setArregoCiudades(response);
    }

    useEffect(() => {
        comboRoles();
        comboCiudades();
        document.getElementById('nombres').focus();
    }, []);

    const onSubmit = (e) => {
        e.preventDefault();
        //crear();
    }

    /*const crear = async () => {
        const body = {
            nombreEspecialidad: nombre
        }
        const response = await APIInvoke.invokePOST(`/api/especialidades`, body);

        if (response.ok === "SI") {
            mensajesFlotantes('success', response.msg);
            navigate("/especialidades-admin");
        } else {
            mensajesFlotantes('error', response.msg);
        }
    }*/

    return (
        <>
            <Header></Header>
            <Sidebar></Sidebar>
            <main id="main" className="main">
                <BreadCrumd
                    BreadCrumd1={"Configuración"}
                    BreadCrumd2={"Listado Usuarios"}
                    BreadCrumd3={"Crear Usuarios"}
                    ruta={"/usuarios-admin"}
                />

                <section className="section dashboard">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">

                                <div className="card">
                                    <div className="card-body">
                                        <h5 className="card-title">Crear Usuario</h5>
                                        <form onSubmit={onSubmit}>

                                            <div className="row mb-3">
                                                <label htmlFor="rol" className="col-sm-2 col-form-label">Seleccione un rol</label>
                                                <div className="col-sm-10">
                                                    <Form.Select aria-label="Default select example"
                                                        style={{ cursor: 'pointer' }}
                                                        id="rol"
                                                        name="rol"
                                                        value={rol}
                                                        onChange={e => setRol(e.target.value)}
                                                    >
                                                        <option value="-8">SELECCIONE</option>
                                                        {
                                                            arregloRoles.map(
                                                                opcion =>
                                                                    <option key={opcion._id} value={opcion._id}>{opcion.nombreRol}</option>
                                                            )
                                                        }
                                                    </Form.Select>
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="ciudad" className="col-sm-2 col-form-label">Seleccione una ciudad</label>
                                                <div className="col-sm-10">
                                                    <Form.Select aria-label="Default select example"
                                                        style={{ cursor: 'pointer' }}
                                                        id="ciudad"
                                                        name="ciudad"
                                                        value={ciudad}
                                                        onChange={e => setCiudad(e.target.value)}
                                                    >
                                                        <option value="-8">SELECCIONE</option>
                                                        {
                                                            arregloCiudades.map(
                                                                opcion =>
                                                                    <option key={opcion._id} value={opcion._id}>{opcion.nombreCiudad}</option>
                                                            )
                                                        }
                                                    </Form.Select>
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="nombres" className="col-sm-2 col-form-label">Nombres</label>
                                                <div className="col-sm-10">
                                                    <input type="text"
                                                        className="form-control"
                                                        id="nombres"
                                                        name="nombres"
                                                        value={nombres}
                                                        onChange={e => setNombres(e.target.value)}
                                                        required
                                                    />
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="apellidos" className="col-sm-2 col-form-label">Apellidos</label>
                                                <div className="col-sm-10">
                                                    <input type="text"
                                                        className="form-control"
                                                        id="apellidos"
                                                        name="apellidos"
                                                        value={apellidos}
                                                        onChange={e => setApellidos(e.target.value)}
                                                        required
                                                    />
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="correo" className="col-sm-2 col-form-label">Correo</label>
                                                <div className="col-sm-10">
                                                    <input type="email"
                                                        className="form-control"
                                                        id="correo"
                                                        name="correo"
                                                        value={correo}
                                                        onChange={e => setCorreo(e.target.value)}
                                                        required
                                                    />
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="celular" className="col-sm-2 col-form-label">Celular</label>
                                                <div className="col-sm-10">
                                                    <input type="number"
                                                        className="form-control"
                                                        id="celular"
                                                        name="celular"
                                                        value={celular}
                                                        onChange={e => setCelular(e.target.value)}
                                                        required
                                                    />
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <label htmlFor="direccion" className="col-sm-2 col-form-label">Dirección</label>
                                                <div className="col-sm-10">
                                                    <input type="text"
                                                        className="form-control"
                                                        id="direccion"
                                                        name="direccion"
                                                        value={direccion}
                                                        onChange={e => setDireccion(e.target.value)}
                                                        required
                                                    />
                                                </div>
                                            </div>

                                            <div className="row mb-3">
                                                <div className="col-sm-12 text-center">
                                                    <button type="submit" className="btn btn-primary">Guardar</button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </>
    );
}

export default UsuariosCrear;