import React from 'react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import CrearCuenta from './paginas/auth/CrearCuenta';
import Login from './paginas/auth/Login';
import CiudadesAdmin from './paginas/configuracion/CiudadesAdmin';
import CiudadesCrear from './paginas/configuracion/CiudadesCrear';
import CiudadesEditar from './paginas/configuracion/CiudadesEditar';
import EspecialidadesAdmin from './paginas/configuracion/EspecialidadesAdmin';
import EspecialidadesCrear from './paginas/configuracion/EspecialidadesCrear';
import EspecialidadesEditar from './paginas/configuracion/EspecialidadesEditar';
import RolesAdmin from './paginas/configuracion/RolesAdmin';
import RolesCrear from './paginas/configuracion/RolesCrear';
import RolesEditar from './paginas/configuracion/RolesEditar';
import UsuariosAdmin from './paginas/configuracion/UsuariosAdmin';
import UsuariosCrear from './paginas/configuracion/UsuariosCrear';
import DashBoard from './paginas/DashBoard';

function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path='/' exact element={<Login />} />
          <Route path='/crear-cuenta' exact element={<CrearCuenta />} />
          <Route path='/dashboard' exact element={<DashBoard />} />
          <Route path='/roles-admin' exact element={<RolesAdmin />} />
          <Route path='/roles-crear' exact element={<RolesCrear />} />
          <Route path='/roles-editar/:id' exact element={<RolesEditar />} />
          <Route path='/ciudades-admin' exact element={<CiudadesAdmin />} />
          <Route path='/ciudades-crear' exact element={<CiudadesCrear />} />
          <Route path='/ciudades-editar/:id' exact element={<CiudadesEditar />} />
          <Route path='/especialidades-admin' exact element={<EspecialidadesAdmin />} />
          <Route path='/especialidades-crear' exact element={<EspecialidadesCrear />} />
          <Route path='/especialidades-editar/:id' exact element={<EspecialidadesEditar />} />
          <Route path='/usuarios-admin' exact element={<UsuariosAdmin />} />
          <Route path='/usuarios-crear' exact element={<UsuariosCrear />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
